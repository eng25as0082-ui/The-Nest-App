/* ── The Nest · app.js ─────────────────────────────── */

// ── DATA ─────────────────────────────────────────────
const MEMBERS = [
  { name: 'Mum',   emoji: '👩', color: '#9FE1CB' },
  { name: 'Dad',   emoji: '👨', color: '#CECBF6' },
  { name: 'Priya', emoji: '👧', color: '#FAC775' },
  { name: 'Arjun', emoji: '👦', color: '#F4C0D1' },
  { name: 'Nani',  emoji: '👵', color: '#B5D4F4' },
];

const PROMPTS = [
  { text: "What's one thing that made you smile today?",           cat: 'fun' },
  { text: "If you could eat only one meal for a week, what would it be?", cat: 'silly' },
  { text: "What's the best memory you have of us all together?",  cat: 'memory' },
  { text: "What superpower would you choose and why?",            cat: 'fun' },
  { text: "Describe your perfect day from morning to night.",     cat: 'deep' },
  { text: "What's something you're really proud of lately?",      cat: 'deep' },
  { text: "If you could visit any place in the world right now, where?", cat: 'fun' },
  { text: "What's a song that's stuck in your head this week?",   cat: 'silly' },
  { text: "What's one thing you'd like to learn this year?",      cat: 'deep' },
  { text: "Tell us something funny that happened recently.",       cat: 'silly' },
  { text: "What's the kindest thing someone did for you recently?", cat: 'memory' },
  { text: "What does home feel like to you?",                     cat: 'deep' },
  { text: "What's your go-to comfort food on a bad day?",         cat: 'fun' },
  { text: "If you could have dinner with anyone — alive or not — who?", cat: 'deep' },
  { text: "What's the weirdest dream you can remember?",          cat: 'silly' },
  { text: "What's a family tradition you love?",                  cat: 'memory' },
  { text: "Show us something on your phone that made you laugh.",  cat: 'silly' },
  { text: "What are you looking forward to most this month?",     cat: 'fun' },
  { text: "What's one piece of advice you'd give your younger self?", cat: 'deep' },
  { text: "What's your hidden talent that the family might not know?", cat: 'silly' },
  { text: "Describe a smell that brings back a strong memory.",   cat: 'memory' },
  { text: "What's the bravest thing you've ever done?",           cat: 'deep' },
  { text: "If our family were a movie, what genre would it be?",  cat: 'silly' },
  { text: "What's one thing you're grateful for today?",          cat: 'deep' },
  { text: "What childhood game do you wish you still played?",    cat: 'memory' },
  { text: "What's something small that brings you joy every day?", cat: 'fun' },
  { text: "If you could only keep three possessions, what are they?", cat: 'deep' },
  { text: "What's the funniest thing a family member has ever said?", cat: 'memory' },
  { text: "What book or show has changed how you see the world?", cat: 'deep' },
  { text: "What would your nickname be if you didn't choose it?", cat: 'silly' },
];

const REACTIONS = ['❤️', '😂', '🥹', '🙌', '🔥'];

// ── STATE ─────────────────────────────────────────────
function getState() {
  return JSON.parse(localStorage.getItem('nest_state') || 'null') || {
    currentUser: null,
    todayPromptIndex: 0,
    customPrompt: null,
    answers: {},       // { "YYYY-MM-DD": { memberName: { text, time, reactions: {emoji: count} } } }
    reactions: {},
    startDate: new Date().toISOString().slice(0, 10),
    memberStats: {},   // { memberName: { answers: 0, streak: 0, lastAnswer: null } }
  };
}

function saveState(s) {
  localStorage.setItem('nest_state', JSON.stringify(s));
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getTodayPrompt(state) {
  if (state.customPrompt) return state.customPrompt;
  const dayNum = Math.floor((new Date(todayKey()) - new Date(state.startDate)) / 86400000);
  return PROMPTS[Math.abs(dayNum) % PROMPTS.length];
}

// ── NAV ───────────────────────────────────────────────
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + id).classList.add('active');
}

function setActiveNav(screenId) {
  document.querySelectorAll('.nav-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === screenId);
  });
}

document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const s = btn.dataset.screen;
    showScreen(s);
    setActiveNav(s);
    if (s === 'home') renderHome();
    if (s === 'prompts') renderPromptLibrary();
    if (s === 'memory') renderMemory();
    if (s === 'family') renderFamily();
  });
});

// ── LOGIN ──────────────────────────────────────────────
document.querySelectorAll('.member-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const state = getState();
    state.currentUser = btn.dataset.member;
    saveState(state);
    showScreen('home');
    renderHome();
  });
});

// ── HOME ───────────────────────────────────────────────
function renderHome() {
  const state = getState();
  if (!state.currentUser) { showScreen('login'); return; }

  const member = MEMBERS.find(m => m.name === state.currentUser);
  document.getElementById('home-avatar').textContent = member.emoji;
  document.getElementById('home-name').textContent = member.name;

  // Date
  const d = new Date();
  document.getElementById('today-date').textContent =
    d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });

  // Streak
  const streak = calcStreak(state);
  document.getElementById('streak-display').textContent = `🔥 ${streak}`;

  // Prompt
  const prompt = getTodayPrompt(state);
  document.getElementById('prompt-text').textContent = prompt.text;

  // Who answered
  const todayAnswers = (state.answers[todayKey()] || {});
  const row = document.getElementById('answered-row');
  row.innerHTML = '';
  MEMBERS.forEach(m => {
    const span = document.createElement('span');
    span.className = 'answered-bubble ' + (todayAnswers[m.name] ? 'done' : 'waiting');
    span.textContent = (todayAnswers[m.name] ? '✓ ' : '') + m.name;
    row.appendChild(span);
  });

  // Answer box
  const alreadyAnswered = !!todayAnswers[state.currentUser];
  document.getElementById('answer-section').style.display = alreadyAnswered ? 'none' : 'block';
  document.getElementById('already-answered').style.display = alreadyAnswered ? 'flex' : 'none';
  document.getElementById('answer-input').value = '';
  document.getElementById('char-count').textContent = '0';

  // Feed
  renderFeed(state, todayAnswers);
}

function renderFeed(state, todayAnswers) {
  const list = document.getElementById('feed-list');
  list.innerHTML = '';
  const entries = Object.entries(todayAnswers);

  if (entries.length === 0) {
    document.getElementById('empty-feed').style.display = 'block';
    return;
  }
  document.getElementById('empty-feed').style.display = 'none';

  entries.sort((a, b) => new Date(a[1].time) - new Date(b[1].time));

  entries.forEach(([name, data]) => {
    const member = MEMBERS.find(m => m.name === name);
    const card = document.createElement('div');
    card.className = 'feed-card';

    const timeStr = new Date(data.time).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

    const reactionCounts = data.reactions || {};
    const reactBtns = REACTIONS.map(e => {
      const count = reactionCounts[e] || 0;
      const reacted = (state.myReactions?.[todayKey()]?.[name]?.[e]);
      return `<button class="reaction-btn ${reacted ? 'reacted' : ''}" data-member="${name}" data-emoji="${e}">
        ${e}${count > 0 ? ' ' + count : ''}
      </button>`;
    }).join('');

    card.innerHTML = `
      <div class="feed-header">
        <span class="feed-emoji">${member.emoji}</span>
        <span class="feed-name">${member.name}</span>
        <span class="feed-time">${timeStr}</span>
      </div>
      <div class="feed-text">${escapeHtml(data.text)}</div>
      <div class="reactions-row">${reactBtns}</div>
    `;

    card.querySelectorAll('.reaction-btn').forEach(btn => {
      btn.addEventListener('click', () => handleReaction(name, btn.dataset.emoji));
    });

    list.appendChild(card);
  });
}

function handleReaction(targetMember, emoji) {
  const state = getState();
  const today = todayKey();

  if (!state.answers[today]?.[targetMember]) return;
  if (!state.answers[today][targetMember].reactions) state.answers[today][targetMember].reactions = {};
  if (!state.myReactions) state.myReactions = {};
  if (!state.myReactions[today]) state.myReactions[today] = {};
  if (!state.myReactions[today][targetMember]) state.myReactions[today][targetMember] = {};

  const already = state.myReactions[today][targetMember][emoji];
  const reactions = state.answers[today][targetMember].reactions;

  if (already) {
    reactions[emoji] = Math.max(0, (reactions[emoji] || 1) - 1);
    state.myReactions[today][targetMember][emoji] = false;
  } else {
    reactions[emoji] = (reactions[emoji] || 0) + 1;
    state.myReactions[today][targetMember][emoji] = true;
  }

  saveState(state);
  renderFeed(state, state.answers[today]);
}

// Answer submission
document.getElementById('answer-input').addEventListener('input', function() {
  document.getElementById('char-count').textContent = this.value.length;
});

document.getElementById('submit-btn').addEventListener('click', () => {
  const input = document.getElementById('answer-input');
  const text = input.value.trim();
  if (!text) { showToast('Write something first! ✍️'); return; }

  const state = getState();
  const today = todayKey();
  if (!state.answers[today]) state.answers[today] = {};

  state.answers[today][state.currentUser] = {
    text,
    time: new Date().toISOString(),
    reactions: {},
  };

  if (!state.memberStats[state.currentUser]) state.memberStats[state.currentUser] = { answers: 0 };
  state.memberStats[state.currentUser].answers++;
  state.memberStats[state.currentUser].lastAnswer = today;

  saveState(state);
  showToast('Shared with the family! 🪺');
  renderHome();
});

// ── STREAK ─────────────────────────────────────────────
function calcStreak(state) {
  const answers = state.answers;
  let streak = 0;
  let d = new Date();
  while (true) {
    const key = d.toISOString().slice(0, 10);
    const dayAnswers = answers[key] || {};
    if (Object.keys(dayAnswers).length === 0) break;
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

// ── PROMPT LIBRARY ─────────────────────────────────────
function renderPromptLibrary() {
  const state = getState();
  const list = document.getElementById('prompt-library-list');
  list.innerHTML = '';
  const current = getTodayPrompt(state).text;

  PROMPTS.forEach((p, i) => {
    const card = document.createElement('div');
    card.className = 'prompt-lib-card' + (p.text === current ? ' active-prompt' : '');
    card.innerHTML = `
      <span class="prompt-lib-text">${p.text}</span>
      <span class="prompt-lib-cat cat-${p.cat}">${p.cat}</span>
    `;
    card.addEventListener('click', () => {
      const s = getState();
      s.customPrompt = p;
      saveState(s);
      showToast("Today's prompt updated! 💬");
      renderPromptLibrary();
    });
    list.appendChild(card);
  });
}

document.getElementById('random-prompt-btn').addEventListener('click', () => {
  const state = getState();
  const r = PROMPTS[Math.floor(Math.random() * PROMPTS.length)];
  state.customPrompt = r;
  saveState(state);
  showToast('New random prompt set! 🎲');
  renderPromptLibrary();
});

// ── MEMORY LANE ────────────────────────────────────────
function renderMemory() {
  const state = getState();
  const list = document.getElementById('memory-list');
  list.innerHTML = '';

  const days = Object.keys(state.answers).sort((a, b) => b.localeCompare(a));

  if (days.length === 0) {
    document.getElementById('empty-memory').style.display = 'block';
    return;
  }
  document.getElementById('empty-memory').style.display = 'none';

  days.forEach(dateKey => {
    const dayAnswers = state.answers[dateKey];
    if (Object.keys(dayAnswers).length === 0) return;

    const d = new Date(dateKey);
    const label = d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

    const block = document.createElement('div');
    block.className = 'memory-day';

    const dayLabel = document.createElement('div');
    dayLabel.className = 'memory-day-label';
    dayLabel.textContent = label;
    block.appendChild(dayLabel);

    Object.entries(dayAnswers).forEach(([name, data]) => {
      const member = MEMBERS.find(m => m.name === name);
      const card = document.createElement('div');
      card.className = 'memory-card';
      card.innerHTML = `
        <span class="memory-emoji">${member.emoji}</span>
        <div class="memory-content">
          <div class="memory-who">${member.name}</div>
          <div class="memory-answer">${escapeHtml(data.text)}</div>
        </div>
      `;
      block.appendChild(card);
    });

    list.appendChild(block);
  });
}

// ── FAMILY TAB ─────────────────────────────────────────
function renderFamily() {
  const state = getState();

  const totalAnswers = Object.values(state.answers)
    .flatMap(day => Object.values(day)).length;
  const daysTogether = Object.keys(state.answers).length;

  document.getElementById('stat-days').textContent = daysTogether;
  document.getElementById('stat-answers').textContent = totalAnswers;

  const flist = document.getElementById('family-members-list');
  flist.innerHTML = '';

  MEMBERS.forEach(m => {
    const stats = state.memberStats[m.name] || { answers: 0 };
    const isMe = m.name === state.currentUser;
    const row = document.createElement('div');
    row.className = 'member-row';
    row.innerHTML = `
      <span class="member-row-emoji">${m.emoji}</span>
      <div class="member-row-info">
        <div class="member-row-name">${m.name}${isMe ? ' <span style="color:var(--accent);font-size:.75rem">(you)</span>' : ''}</div>
        <div class="member-row-stats">${stats.answers || 0} answers shared</div>
      </div>
    `;
    flist.appendChild(row);
  });
}

document.getElementById('logout-btn').addEventListener('click', () => {
  const state = getState();
  state.currentUser = null;
  saveState(state);
  showScreen('login');
});

document.getElementById('reset-btn').addEventListener('click', () => {
  if (confirm('This will delete ALL family answers and data. Are you sure?')) {
    localStorage.removeItem('nest_state');
    location.reload();
  }
});

// ── TOAST ──────────────────────────────────────────────
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

// ── UTILS ──────────────────────────────────────────────
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── INIT ───────────────────────────────────────────────
(function init() {
  const state = getState();
  if (state.currentUser) {
    showScreen('home');
    renderHome();
  } else {
    showScreen('login');
  }
})();
